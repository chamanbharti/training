package com.lynda.common.data.repository;

import org.springframework.stereotype.Repository;

@Repository
public class InventoryItemRepository {
}
