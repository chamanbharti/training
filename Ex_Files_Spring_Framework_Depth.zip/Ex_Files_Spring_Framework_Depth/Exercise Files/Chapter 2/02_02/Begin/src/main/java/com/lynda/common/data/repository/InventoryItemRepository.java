package com.lynda.common.data.repository;

public class InventoryItemRepository {
}
