package com.lynda.common.data.repository;

public class SalesOrderRepository {
}
